<?php
    include "inc/chec.php";
    include "conn/conn.php";
    include "inc/func.php";
?>
<?php include('top.php') ?>
<div class="container">
    <?php include('left.php') ?>
    <div class="right">
        <div class="title">
            最新消息
        </div>
        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color:#DEEBEF;">
            <tr>
                <td width="50%" align="center" valign="top">
                    <table width="100%" height="195" border="0" cellpadding="0" cellspacing="0" class="big_td">
                        <tr>
                            <td height="20" align="center" valign="middle">企业公告</td>
                        </tr>
                        <tr>
                            <td align="center" valign="top">
                                <!--公告-->
                                <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#DEEBEF">
                                    <tr>
                                        <td height="25" align="center" valign="middle">发布时间</td>
                                        <td align="center" valign="middle">标题</td>
                                    </tr>
                                    <?php
                                        $sqlstr = "select * from tb_person where u_id = 9 order by id limit 0,5";
                                        $result = mysqli_query($conn,$sqlstr);
                                        while($rows = mysqli_fetch_assoc($result)):
                                    ?>
                                        <tr>
                                            <td height=30 align=center valign=middle><?php echo $rows['p_time']; ?></td>
                                            <td align="center" valign="middle" style='text-indent: 30px;'>
                                                <a href="javascript:;" onclick="showMessage(<?php echo $rows['id']; ?>)">
                                                    <?php echo $rows['p_title']; ?></a>
                                            </td>
                                        </tr>
                                    <?php endwhile ?>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
                <td align="center" valign="top">
                    <table width="100%" height="195" border="0" cellpadding="0" cellspacing="0" class="big_td">
                        <tr>
                            <td height="20" align="center" valign="middle" scope="col">活动安排</td>
                        </tr>
                        <tr>
                            <td align="center" valign="top">
                                <!--活动-->
                                <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#DEEBEF">
                                    <tr>
                                        <td height="25" align="center" valign="middle">发布时间</td>
                                        <td align="center" valign="middle">标题</td>
                                    </tr>
                                    <?php
                                        $sqlstr = "select * from tb_person where u_id = 10 order by id limit 0,5";
                                        $result = mysqli_query($conn,$sqlstr);
                                        while($rows = mysqli_fetch_row($result)): ?>
                                        <tr>
                                            <td height=30 align=center valign=middle><?php echo $rows[3]; ?></td>
                                            <td align="center" valign="middle" style='text-indent: 30px;'>
                                                <a href="javascript:;" onclick="showMessage(<?php echo $rows[0]; ?>)" style="color: #005f81">
                                                    <?php echo $rows[1]; ?>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile ?>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td width="50%" align="center" valign="top">
                    <table width="100%" height="195" border="0" cellpadding="0" cellspacing="0" class="big_td">
                        <tr>
                            <td height="20" align="center" valign="middle">考勤管理</td>
                        </tr>
                        <tr>
                            <td align="center" valign="top">
                                <!--个人计划-->
                                <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#DEEBEF">
                                    <tr>
                                        <td width="75" height="25" align="center" valign="middle">日期</td>
                                        <td align="center" valign="middle">登记时间</td>
                                        <td align="center" valign="middle">登记类型</td>
                                        <td align="center" valign="middle">登记状态</td>
                                        <td align="center" valign="middle">备注</td>
                                    </tr> 
                                    <?php
										$sqlstr = "select id,r_date,r_time,r_type,r_state,r_remark from tb_register where p_id = ".$_SESSION['id']." order by id desc";
										$result = mysqli_query($conn,$sqlstr);
										while($rows = mysqli_fetch_array($result)){
									?>
                                    <tr>
				<td height="25" align="center" valign="middle"><?php echo $rows['r_date']; ?></td>
				<td height="25" align="center" valign="middle"><?php echo $rows['r_time']; ?></td>
				<td height="25" align="center" valign="middle">

				<?php
					switch($rows['r_type']){
						case 0:
							echo  "下班";
							break;
						case 1:
							echo "上班";
							break;
						case 2:
							echo "加班签到";
							break;
						case 3:
							echo "加班签退";
							break;
						case 4:
							echo "病假";
							break;
						case 5:
							echo "事假";
							break;
					}
				?>

				</td>
				<td height="25" align="center" valign="middle">
				<?php
					switch($rows['r_type']){
						case 1:
							echo ($rows['r_state'] == 0)?"正点上班":"迟到";
							break;
						case 0:
							echo ($rows['r_state'] == 0)?"早退":"正点下班";
							break;
						case 2:
							echo ($rows['r_state'] == 0)?"正点加班":"晚点加班";
							break;
						case 3:
							echo ($rows['r_state'] == 0)?"早退":"正点下班";
							break;
						case 4:
							echo ($rows['r_state'] == 0)?"病假":"事假";
							break;
					}
				?>
				</td>
				<td height="25" align="center" valign="middle"><?php echo ($rows['r_remark'] != null)?$rows['r_remark']:'无'; ?></td>
			</tr>
		<?php
			}
		?>
                                    <?php /*?><?php
                                    $p_sql = "select * from tb_register where p_id = ".$_SESSION['id']." order by id desc limit 0,5";
                                    $p_rst = mysqli_query($conn,$p_sql);
                                    while($p_rows = mysqli_fetch_array($p_rst)) :
                                        ?>
                                        <tr>
                                           <td height="30" align="center" valign="middle"><?php echo $p_rows[1]; ?></td>
                                           <td height="30" align="center" valign="middle"><?php echo $p_rows[2]; ?></td>
                                           <td height="30" align="center" valign="middle"><?php echo $p_rows[3]; ?></td>
                                           <td height="30" align="center" valign="middle"><?php echo $p_rows[4]; ?></td>
                                           <td height="30" align="center" valign="middle"><?php echo $p_rows[5]; ?></td>
                                           
                                            <td height="30" align="center" valign="middle"><?php echo $p_rows['p_time']; ?></td>
                                            <td align="left" valign="middle">
                                                <?php echo substr($p_rows[1],0,20).".........<a href='kqql/work_note.php?id=".$p_rows[0]."' target='_blank'>查看全文</a>"; ?>
                                            </td>
                                            <td width="50" align="center" valign="middle">
                                                <?php echo read_field($conn,"tb_list","f_name",$p_rows['p_type']); ?>
                                            </td>
                                        </tr>
                                    <?php endwhile ?><?php */?>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
                <td align="center" valign="top">
                    <table width="100%" height="195" border="0" cellpadding="0" cellspacing="0" class="big_td">
                        <tr>
                            <td height="20" align="center" valign="middle" scope="col">审核批示</td>
                        </tr>
                        <tr>
                            <td align="center" valign="top">
                                <!--审核批示-->
                                <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#DEEBEF">
                                    <tr>
                                        <td width="75" height="25" align="center" valign="middle">日期</td>
                                        <td height="25" align="center" valign="middle">标题</td>
                                        <td width="50" height="25" align="center" valign="middle">是否批示</td>
                                        <td width="75" height="25" align="center" valign="middle">操作</td>
                                    </tr>
                                    <?php
                                    $a_sql = "select * from tb_iss where p_id = ".$_SESSION['id'];
                                    $a_rst = mysqli_query($conn,$a_sql);
                                    while($a_rows = mysqli_fetch_assoc($a_rst)) :
                                        ?>
                                        <tr>
                                            <td height="30" align="center" valign="middle"><?php echo $a_rows['i_time']; ?></td>
                                            <td height="30" align="left" valign="middle"><?php echo $a_rows['i_title']; ?></td>
                                            <td height="30" align="center" valign="middle">
                                                <?php
                                                if($a_rows['i_state'] == 3)
                                                    echo "未审核";
                                                else
                                                    echo (($a_rows['i_state'] == 0)?"通过":"未通过");
                                                ?>		</td>
                                            <td height="30" align="center" valign="middle">
                                                <a href="shps/modify_issuance.php?id=<?php echo $a_rows['id']; ?>">修改</a>||<a href="shps/del_issuance_chk.php?id=<?php echo $a_rows['id']; ?>">删除</a></td>
                                        </tr>
                                        <?php endwhile ?>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </div>
</div>
<script>
    function showMessage(id){
        url = "./rsxx/show_message.php?id="+id;
        //iframe窗
        layer.open({
            type: 2,
            title: false,
            shade: [0],
            area: ['600px', '400px'],
            anim: 2,
            content: url //iframe的url，no代表不显示滚动条
        });
    }
</script>
</body>
</html>
