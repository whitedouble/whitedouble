<?php
session_start();
include "../conn/conn.php";
include "../inc/chec.php";
include "../inc/func.php";
date_default_timezone_set('Asia/Shanghai'); // 设置时区

$now_date = date("Y-m-d");  // 当前日期
$now_time = date("H:i:s"); //当前登记时间
// r_id类型： 14：上下班 15：病事假 16：加班
// u_type类型： 0:上班签到 1:下班签退 2：加班签到 3：加班签退 4：病假 5：事假
if(($_POST['r_id'] == "14") or ($_POST['r_id'] == "16")){  // 上下班或加班
	if($_POST['u_type'] == 0)       // 下班签退
		$t_sql = "select * from tb_setup where id = 2";
	else if($_POST['u_type'] == 1)  // 上班签到
		$t_sql = "select * from tb_setup where id = 1";
	else if($_POST['u_type'] == 2)  // 加班签到
		$t_sql = "select * from tb_setup where id = 3";
	else if($_POST['u_type'] == 3)  // 加班签退
		$t_sql = "select * from tb_setup where id = 4";	
	$t_rst = mysqli_query($conn,$t_sql);
	$t_rows = mysqli_fetch_assoc($t_rst);
	$s_time = $t_rows['l_time'];//正点时间
	$state = strtotime($now_time) - strtotime($s_time) > 0  ? 1 : 0;
	$l_sql = "insert into tb_register (r_date,r_time,r_type,r_state,r_remark,r_id,p_id) values('$now_date','$now_time',{$_POST['u_type']},$state,'{$_POST['r_remark']}',{$_POST['r_id']},{$_SESSION['id']})";
}else if($_POST['r_id'] == "15"){
	$l_sql = "insert into tb_register (r_date,r_time,r_type,r_state,r_remark,r_id,p_id) values('$now_date','$now_time',{$_POST['u_type']},3,'{$_POST['r_remark']}',{$_POST['r_id']},{$_SESSION['id']})";
}
$l_rst = mysqli_query($conn,$l_sql);

if($l_rst)
	echo "<script>alert('登记完成');var index=parent.layer.getFrameIndex(window.name);parent.layer.close(index);</script>"; # 关闭弹层
else
	echo "<script>alert('错误');history.go(-1);</script>";
?>