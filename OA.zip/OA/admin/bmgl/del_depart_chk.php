<?php
	session_start(); 
	include "../inc/chec.php";
	include "../conn/conn.php";
	include "../inc/func.php";
	$sqlstr = "delete from tb_depart where id = ".$_GET['id'];
	$result = mysqli_query($conn,$sqlstr);
	re_message($result,"show_depart.php");
?>