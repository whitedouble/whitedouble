<?php
if(!isset($_SESSION))
{
    session_start();
}
if(!isset($_SESSION['u_name']))
	echo "<script>alert('您无权访问');location='../index.php';</script>";