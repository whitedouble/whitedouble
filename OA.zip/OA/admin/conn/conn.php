<?php
$conn=mysqli_connect("127.0.0.1","root","","db_office");
mysqli_query($conn,"set names utf8");
?>
