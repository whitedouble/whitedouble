<?php
include "conn/conn.php";
include "inc/func.php";
$sqlstr = "select id,u_name,u_depart,is_on from tb_users where u_user = {$_POST['username']} and u_pwd = {$_POST['pwd']}";
$result = mysqli_query($conn,$sqlstr);
$record = mysqli_fetch_assoc($result);
if(($record != "") and ($record['is_on'] == 1)) {
	if(getGroup($conn,$record['u_name'],$_POST['u_group'])){	# 判断是否属于成员组
        session_start();	# 开启session
		$_SESSION["id"] = $record['id'];
		$_SESSION["u_name"] = $_POST['username'];
		$_SESSION["u_depart"] = read_field($conn,"tb_depart","d_name",$record['u_depart']);
		$_SESSION["u_group"] = read_field($conn,"tb_group","u_group",$_POST['u_group']);
		w_log($_POST['action']); # 写入日志
		echo "<script>alert('欢迎光临');location='pub_main.php';</script>";
	}
	else{
        echo "<script>alert('用户名或密码错误');history.go(-1);</script>";
    }
}
else
	echo "<script>alert('用户名或密码错误');history.go(-1);</script>";
?>