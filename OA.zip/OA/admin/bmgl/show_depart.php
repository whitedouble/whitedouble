<?php
	session_start(); 
	include "../inc/chec.php";
	include "../conn/conn.php";
	include "../inc/func.php";
?>
<?php include('../top.php') ?>
<div class="container">
	<?php include('../left.php') ?>
	<div class="right">
		<!--查看部门信息-->
		<table width="765" height="450" border="0" cellpadding="0" cellspacing="0" style="border: 1px solid #9CBED6; margin-top:15px;">
		<tr><td align="center" valign="top" bgcolor="#DAE9EC">
		<table width="50%" height="25"  border="0" cellpadding="0" cellspacing="0">
		<?php
			//找到根部门
			$sqlstr = "select * from tb_depart where up_depart = 0";
			$result = mysqli_query($conn,$sqlstr);
			//隐藏域id号
			$m = 1;
			//循环输出所有根部门
			while($rows = mysqli_fetch_row($result)){
				$wid = 100;
				//查看下属部门
				$sqlstr1 = "select * from tb_depart where up_depart = ".$rows[0];
				$result1 = mysqli_query($conn,$sqlstr1);
				$nu = mysqli_num_rows($result1);
				//如果当前部门没有下属部门时
				if(!$nu){
				?>
			<tr>
				<td height="25">
					<a href="<?php echo $_SESSION['PHP_SELF']; ?>">
                        <img src="../Images/folder.gif" width="30" height="16" border="0" >&nbsp;<?php echo $rows[1]; ?>
					</a>
					------------------
                    <a href="edit_depart.php?id=<?php echo $rows[0]; ?>">修改</a>||
                    <a href="del_depart_chk.php?id=<?php echo $rows[0] ?>" onClick="return cfm();">删除</a></td>
			</tr>
				<?php
				//如果当前部门有下属部门时
				}else{
				?>
			<tr>
				<td height="25">
                    <a href="Javascript:ShowTR(img<?php echo $m; ?>,OpenRep<?php echo $m; ?>)">
                        <img src="../Images/jia.gif" alt="展开" name="img<?php echo $m; ?>" width="32" height="14" border="0" id="img<?php echo $m; ?>">
                        &nbsp;<?php echo $rows[1]; ?></a>------------------
                    <a href="edit_depart.php?id=<?php echo $rows[0]; ?>">修改</a>||删除</td>
			</tr>
				<?php
					//输出同级部门
					list_menu($rows[0],$wid,$m);
						$m += 1;
					}
				}
				?>
		</table>
		</td></tr>
		</table>
	</div>
</div>
</body>
</html>