<?php
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
	include "../inc/func.php";
	$sqlstr = "delete from tb_register";
	$result = mysqli_query($conn,$sqlstr);
	re_message($result,"manage_note.php");
?>