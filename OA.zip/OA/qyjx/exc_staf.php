<?php
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
    if(!isset($_SESSION["u_depart"]) or $_SESSION["u_depart"] != '部门经理'){
        echo "<script>alert('非部门经理无权访问');history.go(-1)</script>";
        exit();
    }
	$sqlstr = "select * from tb_superson order by s_fmonth desc";
	$result = mysqli_query($conn,$sqlstr);
?>
<?php include('../top.php') ?>
<div class="container">
	<?php include('../left.php') ?>
	<div class="right">
		<table width="765" border="1" cellpadding="0" cellspacing="0" class="big_td">
			<tr>
				<td height="33" background="../images/list.jpg" id="list">优秀员工</td>
			</tr>
		</table>
		<table width="765" border="1" cellpadding="0" cellspacing="0" class="big_td">
		<?php
			while($rows = mysqli_fetch_row($result)){
		?>
			<tr>
				<td height="25" width="300"><a href="?cont=<?php echo $rows[3]; ?>"><?php echo $rows[1]; ?> 到 <?php echo $rows[2]; ?>优秀员工</a></td>
				<td width="25" align="center" valign="middle"><a href="del_exc_chk.php?id=<?php echo $rows[0] ?>">删除</a></td>
			</tr>
		<?php
			}
		?>
		<tr>
			<td colspan="2" height="200" align="center" valign="middle">
			<?php
                $cont = isset($_GET['cont']) ? $_GET['cont'] : '';
				echo $cont;
			?>
			</td>
		</tr>
		</table>
	</div>
</div>
</body>
</html>