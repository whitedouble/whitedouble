<?php
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['controller']))
	echo "<script>alert('您无权访问');location='../index.php';</script>";
?>