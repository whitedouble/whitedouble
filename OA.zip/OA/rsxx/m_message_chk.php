<?php
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
	include "../inc/func.php";
	$sqlstr = "update tb_person set p_title = '".$_POST['p_title']."',p_content = '".$_POST['p_content']."',p_time = now(),u_id = ".$_POST['p_type']." where id = ".$_POST['id'];
	$result = mysqli_query($conn,$sqlstr);
	re_message($result,"p_manage.php");
?>