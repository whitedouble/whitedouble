<?php
	session_start(); 
	include "../conn/conn.php";
	if($_GET['action'] == "t")
		$sqlstr = "select * from tb_plan where (p_type = 21 or p_type = 22) and p_id = ".$_GET['p_id']; 	// 年计划和任务计划
	else if($_GET['action'] == "m")
		$sqlstr = "select * from tb_plan where (p_type>=18 and  p_type <= 20) and p_id = ".$_GET['p_id'];	// 工作反馈、周计划、月计划
	$result = mysqli_query($conn,$sqlstr);
?>
	<?php
	if($rows = mysqli_fetch_array($result)){
	?>
		<tr>
			<td height="30"><?php echo substr($rows[1],0,50)."........."; ?></td>
			<td>
				<a href="javascript:;" onclick="showPlan(<?php echo $rows[0]; ?>)">查看原文</a>
			</td>
			<td width="30" align="center" valign="middle"><a href="del_plan_chk.php?id=<?php echo $rows[0]; ?>">删除</a></td>
		</tr>
		<?php
			while($rows = mysqli_fetch_array($result)){
				?>
				<tr>
					<td height="30"><?php echo substr($rows[1],0,50)."........."; ?></td>
					<td>
						<a href="javascript:;" onclick="showPlan(<?php echo $rows[0]; ?>)">查看原文</a>
					</td>
					<td height="30" align="center" valign="middle">
                        <a href="del_plan_chk.php?id=<?php echo $rows[0]; ?>">删除</a></td>
				</tr>
		<?php	}
		}else{
		?>
		<tr>
			<td height="30">暂无业绩</td>
		</tr>
	<?php
	}
	?>
	</table>
    </div>
</div>
<script src="/js/jquery-2.1.1.min.js"></script>
<script src="/js/layer/layer.js"></script>
<script>
    function showPlan(id){
        url = "show_plan.php?id="+id;
        //iframe窗
        layer.open({
            type: 2,
            title: false,
            shade: [0],
            area: ['600px', '400px'],
            anim: 2,
            content: url //iframe的url，no代表不显示滚动条
        });
    }
</script>
</body>
</html>


