<?php
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
	$sqlstr = "update tb_group set u_group = '".$_POST['u_group']."', u_member = '".$_POST['g_list']."' where id = ".$_POST['id'];
	$result = mysqli_query($conn,$sqlstr);
	if($result)
		echo "<script>alert('操作成功！');location='user_group.php';</script>";
	else
		echo "<script>alert('系统繁忙，请稍后再试');history.go(-1);</script>";
?>