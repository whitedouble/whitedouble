<?php
session_start();
$result_dest = session_destroy(); //销毁session
if($result_dest){
    echo "<script>window.location.href='/index.php'</script>";
}else{
    echo "退出失败";
}
?>
