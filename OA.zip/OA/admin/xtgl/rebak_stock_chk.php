<?php
	header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
	$mysqlstr = "D:\\PhpStudy\\PHPTutorial\\MySQL\\bin\\mysqldump -uroot -hlocalhost -proot db_office < ../bak/".$_POST['r_name'];
	exec($mysqlstr);
	echo "<script>alert('恢复成功');location='data_stock.php'</script>";
?>
