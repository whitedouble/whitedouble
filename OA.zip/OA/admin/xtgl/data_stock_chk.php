<?php
	header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
	$mysqlstr = "D:\\PhpStudy\\PHPTutorial\\MySQL\\bin\\mysqldump -uroot -hlocalhost -proot --opt -B db_office > ../bak/".$_POST['b_name'];
	exec($mysqlstr);
	echo "<script>alert('备份成功');location='data_stock.php'</script>";
?>
