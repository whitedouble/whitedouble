<?php
header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
	include "../inc/chec.php";
?>
<?php include('../top.php') ?>
<div class="container">
  <?php include('../left.php') ?>
  <div class="right">
    <table width="765" height="450" border="0" cellpadding="0" cellspacing="0" style="border: 1px solid #9CBED6; margin-top:15px;">
      <tr><td align="center" valign="middle">
        <form name="mod_pwd" id="mod_pwd" method="post" action="modify_pwd_chk.php">
          <table width="300" height="116" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="126" align="right" valign="middle">旧密码：</td>
              <th width="174" align="left" valign="middle"><input name="old_pwd" type="password" id="old_pwd" size="15"></th>
            </tr>
            <tr>
              <td align="right" valign="middle">新密码：</td>
              <td align="left" valign="middle"><input name="new_pwd" type="password" id="new_pwd" size="15"></td>
            </tr>
            <tr>
              <td align="right" valign="middle">确认密码：</td>
              <td align="left" valign="middle"><input name="two_pwd" type="password" id="two_pwd" size="15"></td>
            </tr>
            <tr>
              <td colspan="2" align="center" valign="middle"><input type="submit" nanme="submit" value="修改" onclick="return mod_chk();"></td>
            </tr>
          </table>
        </form>
        </td></tr></table>