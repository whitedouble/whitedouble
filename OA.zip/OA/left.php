<?php
include('conn\conn.php');
$sqlstr = "select id,f_type from tb_list group by f_type order by id";
$menu = mysqli_query($conn,$sqlstr);
?>
<div class="left">
    <div class="menu">
        <?php  while($t_rows = mysqli_fetch_assoc($menu)) : ?>
        <div class="menu-item">
            <div class="menu-head">
                <a id="s<?php echo $t_rows['id'] ?>" href="javascript:change(e<?php echo $t_rows['id'] ?>,s<?php echo $t_rows['id'] ?>)">
                    <?php echo $t_rows['f_type'] ?>
                </a>
            </div>
            <div id="e<?php echo $t_rows['id'] ?>" class="sub-menu" style="display: none">
                <?php
                    $sqlstr = "select * from tb_list where f_type= '{$t_rows['f_type']}' and find_in_set('{$_SESSION['u_group']}',o_group)";
                    $sub_menu = mysqli_query($conn,$sqlstr);
                    while($rows = mysqli_fetch_assoc($sub_menu)) :
                ?>
                    <div>
                        <a href="/<?php echo $rows['o_url'].'?u_id='.$rows['id']?>">
                            <?php echo $rows['f_name'] ?>
                        </a>
                    </div>
                    <?php endwhile ?>
            </div>
        </div>
        <?php endwhile ?>
    </div>
</div>