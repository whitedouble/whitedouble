<?php
if(!isset($_SESSION))
{
    session_start();
}
include "inc/chec.php";
?>
<div class="left">
    <div class="menu">
        <div class="menu-item">
            <div class="menu-head">
                <a id="s1" href="javascript:change(e1,s1)">
                    部门管理
                </a>
            </div>
            <div id="e1" class="sub-menu" style="display: none;">
                <div>
                    <a href="/admin/bmgl/show_depart.php">
                        查看部门
                    </a>
                </div>
                <div>
                    <a href="/admin/bmgl/add_depart.php">
                        添加部门
                    </a>
                </div>
            </div>
        </div>
        <div class="menu-item">
            <div class="menu-head">
                <a id="s5" href="javascript:change(e5,s5)">
                    职员管理
                </a>
            </div>
            <div id="e5" class="sub-menu" style="display: none">
                <div>
                    <a href="/admin/zygl/show_staf.php">
                        查看职员
                    </a>
                </div>
                <div>
                    <a href="/admin/zygl/add_staf.php">
                        添加职员
                    </a>
                </div>
            </div>
        </div>
        <div class="menu-item">
            <div class="menu-head">
                <a id="s9" href="javascript:change(e9,s9)">
                    权限管理
                </a>
            </div>
            <div id="e9" class="sub-menu" style="display: none">
                <div>
                    <a href="/admin/qxgl/accounts_purview.php">
                        账号权限
                    </a>
                </div>
                <div>
                    <a href="/admin/qxgl/user_group.php">
                        用户组设置
                    </a>
                </div>
                <div>
                    <a href="/admin/qxgl/pur_assign.php">
                        权限分配
                    </a>
                </div>
            </div>
        </div>
        <div class="menu-item">
            <div class="menu-head">
                <a id="s12" href="javascript:change(e12,s12)">
                    系统管理
                </a>
            </div>
            <div id="e12" class="sub-menu" style="display: none">
                <div>
                    <a href="/admin/xtgl/slog.php">
                        系统日志
                    </a>
                </div>
                <div>
                    <a href="/admin/xtgl/data_stock.php">
                        数据备份
                    </a>
                </div>
                <div>
                    <a href="/admin/xtgl/modify_pwd.php">
                        修改密码
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>