<?php
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
?>
<?php include('../top.php') ?>
<div class="container">
	<?php include('../left.php') ?>
	<div class="right">
		<table width="765" border="1" cellpadding="0" cellspacing="0" class="big_td">
			<tr>
				<td height="33" background="../images/list.jpg" id="list">
				<?php
				if($_GET['u_id'] == 9)
					echo "企业公告";
				elseif($_GET['u_id'] == 10)
					echo "活动安排";
				?>
				</td>
			</tr>
		</table>
		<table width="765" border="1" cellpadding="0" cellspacing="0" bgcolor="#DEEBEF" class="big_td">
			<tr>
				<td width="100" height="25" align="center" valign="middle">发布时间</td>
				<td align="center" valign="middle">标题</td>
			</tr>
		<?php
			if(isset($_GET['u_id'])){
				$sqlstr = "select * from tb_person where u_id = ".$_GET['u_id'];
				$result = mysqli_query($conn,$sqlstr);
				while($rows = mysqli_fetch_row($result)){
		?>
			<tr>
				<td height=30 align=center valign=middle><?php echo $rows[3]; ?></td>
				<td style='text-indent: 30px;'>
				<a href="javascript:;" onclick="showMessage(<?php echo $rows[0]; ?>);"><?php echo $rows[1]; ?></a>
				</td>
			</tr>
		<?php
				}}
		?>
		</table>
	</div>
</div>
<script>
    function showMessage(id){
        var url = 'show_message.php?id='+id;
        //iframe窗
        layer.open({
            type: 2,
            title: false,
            shade: [0],
            area: ['420px', '280px'],
            anim: 2,
            scrollbar: false,
            content: [url,'no'], //iframe的url，no代表不显示滚动条
        });
    }
</script>
</body>
</html>