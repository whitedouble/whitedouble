<?php
	session_start(); 
	include "../inc/chec.php";
	include "../conn/conn.php";
	include "../inc/func.php";
	//判断输入部门名称是否重复
	if(isbool($_POST['d_name'],$conn)){
		echo "<script>alert('名称已存在，请重新输入!');history.go(-1);</script>";
		exit();
	}
	//添加部门，确定上级部门和根部门
	if($_POST['u_id'] != "0"){
		$sqlstr = "select up_depart from tb_depart where id = ".$_POST['u_id'];
		$result = mysqli_query($conn,$sqlstr);
		$rows = mysqli_fetch_row($result);
		if ($rows['up_depart'] != 0)
		$up_depart = $rows['up_depart'];
	else
		$up_depart = $_POST['u_id'];
	}
	else
		$up_depart = 0;
	$sqlstr = "insert into tb_depart values(null,'".$_POST['d_name']."',".$up_depart.",'".$_POST['remark']."')";
	$result = mysqli_query($conn,$sqlstr);
	//调用输出函数
	re_message($result,"show_depart.php")
?>
