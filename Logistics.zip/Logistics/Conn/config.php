<?php
// ���ݿ������ļ�
define("DB_HOST",'localhost');
define("DB_USER",'root');
define('DB_PWD','');
define('DB_NAME','db_logistics');
define('DB_PORT','3306');
define('DB_TYPE','mysql');
define('DB_CHARSET','utf8');
define('DSN',"mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET);
// �������ݿ�
try{
    $pdo = new PDO(DSN,DB_USER,DB_PWD);
}catch (PDOException $e){
    echo $e->getMessage();
}