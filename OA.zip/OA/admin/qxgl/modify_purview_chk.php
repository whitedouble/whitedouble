<?php
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
$sqlstr = "update tb_users set is_on = '".$_GET['is_on']."' where id = ".$_GET['id'];
	$result = mysqli_query($conn,$sqlstr);
	if($result)
		echo "<script>alert('修改成功！');location='accounts_purview.php';</script>";
	else
		echo "<script>alert('系统繁忙，请稍后再试');history.go(-1);</script>";
?>