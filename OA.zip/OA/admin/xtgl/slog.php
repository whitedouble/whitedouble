<?php
	header ( "Content-type: text/html; charset=utf-8" ); //设置文件编码格式
	session_start();
	include "../inc/chec.php";
?>
<?php include('../top.php') ?>
<div class="container">
	<?php include('../left.php') ?>
	<div class="right">
		<table width="765" height="450" border="0" cellpadding="0" cellspacing="0" style="border: 1px solid #9CBED6; margin-top:15px;">
			<tr><td align="center" valign="middle">
				<table border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td colspan="4" height="30" align="center" valign="middle"><a href="del_slog_chk.php" onClick="return del_chk();">清除日志</a></td>
					</tr>
					<tr>
						<td height="25" align="center">登录账号</td>
						<td height="25" align="center">登录时间</td>
						<td height="25" align="center">登录IP</td>
						<td height="25" align="center">登录操作</td>
					</tr>
				<?php
					$filename =  "../log.txt";
                    if(!file_exists($filename)){
                        echo "<script>alert('还没有日志文件！');history.go(-1);</script>";
                        exit();
                    }
					$f_open = fopen($filename,"r");
                    while($str = fgets($f_open,255)){
                        $chr = explode(',',$str);
                        echo "<tr>";
                        for($i = 0; $i < count($chr); $i++){
                            echo "<td align='center' height='25'>".$chr[$i]."</td>";
                        }
                        echo "</tr>";
                    }
                    fclose($f_open);
				?>
				</table>
				</td>
			</tr>
		</table>

