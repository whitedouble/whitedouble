<?php
    include('Conn\config.php');         // 引入配置文件
    include('Library\function.php');    // 引入函数库
    
    /** 接收数据 **/
    $admin_user = $_POST['admin_user'];
    $admin_pass  = md5($_POST['admin_pass']);   // 使用md5加密
    $admin_new_pass = md5($_POST['admin_new_pass']);  // 使用md5加密

    // 添加数据到tb_admin表
    $query = "insert into tb_admin(admin_user,admin_pass)values('$admin_user','$admin_pass')";
    $update = $pdo->prepare($query);
    $update->execute();
    if($update->rowCount()){
        msg(1,'操作成功','login.php');
    }else{
        msg(2,'操作失败','login.php');
    }

?>