<?php
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
	include "../inc/func.php";
	$sqlstr = "insert into tb_person values('','".$_POST['p_title']."','".$_POST['p_content']."',now(),'".$_POST['p_type']."')";
	$result = mysqli_query($conn,$sqlstr);
	re_message($result,"p_manage.php");
?>