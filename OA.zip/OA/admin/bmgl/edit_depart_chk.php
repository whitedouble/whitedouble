<?php
	session_start(); 
	include "../inc/chec.php";
	include "../conn/conn.php";
	include "../inc/func.php";
//�޸Ĳ��ţ�ȷ���ϼ����ź͸�����
if($_POST['u_id'] != 0){
	$sqlstr = "select up_depart from tb_depart where id = ".$_POST['u_id'];
	$result = mysqli_query($conn,$sqlstr);
	$rows = mysqli_fetch_array($result);
	if ($rows['up_depart'] != 0)
		$up_depart = $rows['up_depart'];
	else
		$up_depart = $_POST['u_id'];
}
else
	$up_depart = 0;
	$sqlstr = "update tb_depart set d_name = '".$_POST['d_name']."',up_depart = ".$up_depart.", up_depart = ".$_POST['u_id'].", remark = '".$_POST['remark']."' where id = ".$_POST['id'];
	$result = mysqli_query($conn,$sqlstr);
	re_message($result,"show_depart.php");
?>

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
