<?php
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
	$sqlstr = "insert into tb_superson(s_fmonth,s_lmonth,s_id) values('{$_POST['s_fmonth']}','{$_POST['s_lmonth']}','{$_POST['s_id']}')";
	$result = mysqli_query($conn,$sqlstr);
    if($result)
		echo "<script>alert('操作成功！');location='exc_staf.php';</script>";
	else
		echo "<script>alert('系统繁忙，请稍后再试');history.go(-1);</script>";
?>