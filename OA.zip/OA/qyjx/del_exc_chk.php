<?php
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
	include "../inc/func.php";
	$sqlstr = "delete from tb_superson where id = ".$_GET['id'];
	$result = mysqli_query($conn,$sqlstr);
	re_message($result,"exc_staf.php");
?>
