<?php
session_start();
include "../conn/conn.php";
include "../inc/chec.php";
include "../inc/func.php";
$sqlstr = "delete from tb_lyb where id = ".$_GET['id'];
$result = mysqli_query($conn,$sqlstr);
re_message($result,"lyb.php?u_id=24");
?>