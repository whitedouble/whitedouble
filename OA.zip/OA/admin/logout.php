<?php
session_start(); //启动会话
$result_dest = session_destroy(); //销毁session
?>
<script>
    location.href="/admin/index.php";
</script>