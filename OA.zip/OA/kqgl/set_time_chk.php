<?php
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
	if(isset($_POST['u_logo'])){
		$sqlstr = "update tb_setup set l_time ='".$_POST['l_time0']. "' where id = 1";
	}else if(isset($_POST['d_logo'])){
		$sqlstr = "update tb_setup set l_time ='".$_POST['l_time1']. "' where id = 2";
	}else if(isset($_POST['a_logo'])){
		$sqlstr = "update tb_setup set l_time ='".$_POST['l_time2']. "' where id = 3";
	}else if(isset($_POST['q_logo'])){
		$sqlstr = "update tb_setup set l_time ='".$_POST['l_time3']. "' where id = 4";
	}
	else
		echo "<script>alert('非法登录');var index=parent.layer.getFrameIndex(window.name);parent.layer.close(index);</script>";
	$result = mysqli_query($conn,$sqlstr);
	if($result)
		echo "<script>alert('设置成功');var index=parent.layer.getFrameIndex(window.name);parent.layer.close(index);</script>";
	else
		echo "<script>alert('设置失败');var index=parent.layer.getFrameIndex(window.name);parent.layer.close(index);</script>";
?>