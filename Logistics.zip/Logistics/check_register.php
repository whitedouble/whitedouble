<?php include('View/header.html') ?>
<div class="container-fluid">
        <div class="main-right  col-md-10 col-md-offset-2">
            <div class="col-md-12">
                <div class="panel panel-default ">
                    <div class="panel-heading">
                        注册新用户
                    </div>
                    <div class="panel-body">
                        <form id="password-form" action="store_registerpwd.php" method="post" class="col-md-6" style="padding-left: 10px">
                            <div class="form-group">
                                <label for="admin_user">用户名</label>
                                <input type="text" class="form-control" id="admin_user" name="admin_user">
                            </div>
                            <div class="form-group">
                                <label for="admin_pass">密码</label>
                                <input type="password" class="form-control" id="admin_pass" name="admin_pass" >
                            </div>
                            <div class="form-group">
                                <label for="admin_new_pass">确认密码</label>
                                <input type="password" class="form-control" id="admin_new_pass" name="admin_new_pass" >
                            </div>
                            <button type="submit" class="btn btn-primary">提交</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>

<script>
    $(function () {
        $('#password-form').submit(function () {
            if(!checkField('#admin_user','请输入用户名!')){
                return false;
            }
            if(!checkField('#admin_pass','请输入密码')){
                return false;
            }
            // 判断两次输入新密码是否一致
            if($('#admin_pass').val() != $('#admin_new_pass').val()) {
                layer.tips('两次输入密码不一致', '#admin_new_pass', {time: 2000, tips: 2});
                $("#admin_new_pass").focus();
                return false;
            }
            return true;
        })
    });

    function checkField(id,message){
        if($(id).val() == ''){
            layer.tips(message, id, {time: 2000, tips: 2});
            $(id).focus();
            return false;
        }
        return true;
    }

    function checkPhone(id,message){
        if(!checkField(id,message)){
            return false;
        }
        var tel = $(id).val();
        if(!(/^(\d{3}-)(\d{8})$|^(\d{4}-)(\d{7})$|^(\d{4}-)(\d{8})$|^(\d{11})$/.test(tel))){
            layer.tips('电话格式错误!', id, {time: 2000, tips: 2});
            $(id).focus();
            return false;
        }
        return true;
    }
</script>

<?php include('View\footer.html') ?>


