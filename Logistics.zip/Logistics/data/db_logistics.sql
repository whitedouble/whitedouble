/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : db_logistics

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-05-10 13:19:09
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tb_admin
-- ----------------------------
DROP TABLE IF EXISTS `tb_admin`;
CREATE TABLE `tb_admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `admin_user` varchar(50) NOT NULL COMMENT '管理员名',
  `admin_pass` varchar(50) NOT NULL COMMENT '密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='管理员表';

-- ----------------------------
-- Records of tb_admin
-- ----------------------------
INSERT INTO `tb_admin` VALUES ('1', 'mr', 'fdb390e945559e74475ed8c8bbb48ca5');

-- ----------------------------
-- Table structure for tb_car
-- ----------------------------
DROP TABLE IF EXISTS `tb_car`;
CREATE TABLE `tb_car` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(50) NOT NULL COMMENT '车主名称',
  `user_number` varchar(50) NOT NULL COMMENT '身份证号',
  `car_number` varchar(50) NOT NULL COMMENT '车牌号',
  `tel` varchar(50) NOT NULL COMMENT '车主电话',
  `address` varchar(80) NOT NULL COMMENT '车主地址',
  `car_road` mediumtext NOT NULL COMMENT '路线',
  `car_content` mediumtext NOT NULL COMMENT '车辆描述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='车辆信息表';

-- ----------------------------
-- Records of tb_car
-- ----------------------------
INSERT INTO `tb_car` VALUES ('15', '王师傅', '22032282110365****', '吉A78745', '1360433****', '长春市', '长春-沈阳-大连', '大货车,直径3.8米,后直径4.12米,长24米,载重52吨');
INSERT INTO `tb_car` VALUES ('19', '孙师傅', '22032282110365****', '吉A78746', '1360433****', '长春市', '长春-沈阳-大连', '大货车,直径3.8米,后直径4.12米,长24米,载重55吨');
INSERT INTO `tb_car` VALUES ('21', '刘师傅', '22033219601101****', '吉A78747', '1360433****', '长春市', '长春-北京-郑州', '比亚迪 T7 4×2 轴距4250mm 载货车');
INSERT INTO `tb_car` VALUES ('20', '赵师傅', '22072419540231****', '吉A78749', '1370433****', '长春市', '长春-沈阳-青岛', '北京牌重卡 336马力 6X2 牵引车(BJ4250TSZ22)(轻量化)');
INSERT INTO `tb_car` VALUES ('18', '张师傅', '22072419630224****', '吉A11111', '1362221****', '长春市', '长春市-哈尔滨', '长安重汽 M系列 380马力 6×4 LNG半挂牵引车 SXQ425M7N-4');
INSERT INTO `tb_car` VALUES ('29', '冯师傅', '22072419670222****', '吉A89KE1', '1379211****', '长春市', '长春-北京-重庆', '梅赛德斯-奔驰新Actros 2642 LS DNA 6x2公路牵引车。');

-- ----------------------------
-- Table structure for tb_car_log
-- ----------------------------
DROP TABLE IF EXISTS `tb_car_log`;
CREATE TABLE `tb_car_log` (
  `log_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `car_number` varchar(50) NOT NULL COMMENT '车牌号',
  `car_log` mediumtext NOT NULL COMMENT '车辆日志信息',
  `log_date` datetime NOT NULL COMMENT '日志创建时间',
  `fahuo_id` varchar(50) NOT NULL COMMENT '发货单ID',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='车辆日志信息表';

-- ----------------------------
-- Records of tb_car_log
-- ----------------------------
INSERT INTO `tb_car_log` VALUES ('23', '吉A78747', '11月15日送达', '2017-11-29 09:40:56', '2017112909375621');
INSERT INTO `tb_car_log` VALUES ('25', '吉A89KE1', '12月1日送达', '2017-11-30 11:02:22', '20171130114532');

-- ----------------------------
-- Table structure for tb_customer
-- ----------------------------
DROP TABLE IF EXISTS `tb_customer`;
CREATE TABLE `tb_customer` (
  `customer_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `customer_user` varchar(50) NOT NULL DEFAULT '' COMMENT '客户姓名',
  `customer_tel` varchar(50) NOT NULL DEFAULT '' COMMENT '客户电话',
  `customer_address` varchar(80) NOT NULL DEFAULT '' COMMENT '客户地址',
  PRIMARY KEY (`customer_id`) COMMENT '客户信息表'
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COMMENT='客户信息表';

-- ----------------------------
-- Records of tb_customer
-- ----------------------------
INSERT INTO `tb_customer` VALUES ('41', '张三', '1891044****', '卫星广场');
INSERT INTO `tb_customer` VALUES ('42', '王五', '1321010****', '长春');
INSERT INTO `tb_customer` VALUES ('43', '欧阳锋', '1891044****', '长春汽车厂');
INSERT INTO `tb_customer` VALUES ('50', '郭靖', '1891044****', '长春');

-- ----------------------------
-- Table structure for tb_shopping
-- ----------------------------
DROP TABLE IF EXISTS `tb_shopping`;
CREATE TABLE `tb_shopping` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `car_number` varchar(50) NOT NULL COMMENT '车牌号',
  `fahuo_content` mediumtext NOT NULL COMMENT '货物描述',
  `fahuo_id` varchar(50) NOT NULL COMMENT '发货单ID',
  `fahuo_user` varchar(50) NOT NULL COMMENT '发货人',
  `fahuo_time` datetime NOT NULL COMMENT '发货时间',
  `fahuo_ys` tinyint(20) DEFAULT '0' COMMENT '回执单确认，0：未确认；1：已确认',
  `fahuo_fk` tinyint(20) NOT NULL DEFAULT '0' COMMENT '付款方式，0：发货人付款；1：第三方付款',
  `fahuo_tel` varchar(50) NOT NULL COMMENT '发货人电话',
  `fahuo_address` mediumtext NOT NULL COMMENT '发货地址',
  `car_tel` varchar(50) NOT NULL COMMENT '车主电话',
  `shouhuo_user` varchar(50) NOT NULL COMMENT '收货人姓名',
  `shouhuo_address` mediumtext NOT NULL COMMENT '收货人地址',
  `shouhuo_tel` varchar(50) NOT NULL COMMENT '收货人电话',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='发货单信息表';

-- ----------------------------
-- Records of tb_shopping
-- ----------------------------
INSERT INTO `tb_shopping` VALUES ('22', '吉A89KE1', '东北特产松子一吨', '2017112817141229', '张三', '2017-11-29 09:46:01', '0', '0', '1891044****', '卫星广场', '1891044****', '李四', '重庆南岸区沙坪坝', '1891044****');
INSERT INTO `tb_shopping` VALUES ('23', '吉A78747', '富士苹果一顿', '2017112909375621', '王五', '2017-11-29 09:40:56', '1', '1', '1321010****', '长春', '1357898****', '赵六', '郑州火车站', '1351234****');
INSERT INTO `tb_shopping` VALUES ('24', '吉A11111', '一汽轿车10辆', '20171130105101', '欧阳锋', '2017-11-30 11:02:22', '1', '0', '1891044****', '长春汽车厂', '1891044****', '洪七公', '哈尔滨道里区', '1891044****');
INSERT INTO `tb_shopping` VALUES ('25', '吉A89KE1', '哈尔滨红肠500箱', '20171130114532', '郭靖', '2017-11-30 11:47:51', '1', '0', '1891044****', '长春', '1379211****', '黄蓉', '重庆南岸区沙坪坝万达广场', '1891033****');
