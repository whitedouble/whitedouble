<?php
	session_start(); 
	include "../inc/chec.php";
	include "../conn/conn.php";
	if(!isset($_SESSION["u_depart"]) or $_SESSION["u_depart"] != '部门经理'){
		echo "<script>alert('非部门经理无权访问');history.go(-1)</script>";
		exit();
	}
	$sqlstr = "select * from tb_depart where up_depart != 0 group by up_depart";
	$result = mysqli_query($conn,$sqlstr);
?>
<!--部门列表-->
<?php include('../top.php') ?>
<div class="container">
	<?php include('../left.php') ?>
	<div class="right">
		<table width="765" border="1" cellpadding="0" cellspacing="0" class="big_td">
			<tr>
				<td height="33" background="../images/list.jpg" id="list">质量绩效</td>
			</tr>
		</table>
		<table width="765" border="1" cellpadding="0" cellspacing="0" class="big_td">
		<?php
			$i = 0;
				while($rows = mysqli_fetch_row($result)){
					$a_id[$i] = $rows[2];
					$i++;
				}
				$sqlstr1 = "select id,d_name from tb_depart where id != 0 ";
				$name = "";
				for($j = 0; $j < count($a_id); $j++){
					$sqlstr1 = $sqlstr1." and id != ".$a_id[$j];
				}
				$result1 = mysqli_query($conn,$sqlstr1);
		?>
			<tr>
		<?php
				$num = 0;
				while($rows1 = mysqli_fetch_row($result1)){

					if($num < 10){
		?>
						<td width="50" height="25" align="center" valign="middle"><a href="?d_id=<?php echo $rows1[0]?>"><?php echo $rows1[1]; ?></a></td>
		<?php
					}else{
		?>
		  </tr><tr>
			<td width="50" height="25" align="center" valign="middle"><a href="?d_id=<?php echo $rows1[0]?>"><?php echo $rows1[1]; ?></a></td>
		<?php
						$num = 0;
					}
					$num++;
				}
		?>
			</tr>
		</table>
		<!--部门员工-->
		<table border="0" cellpadding="0" cellspacing="0"  bgcolor="#DEEBEF">
			<tr>
		<?php
				$u_depart = isset($_GET['d_id']) ? $_GET['d_id'] : 0;
				$p_sql = "select id,u_name from tb_users where u_depart = '".$u_depart."'";
				$p_rst = mysqli_query($conn,$p_sql);
				$num = 0;
				while($p_rows = mysqli_fetch_row($p_rst)){

					if($num < 10){
		?>
						<td width="50" height="25" align="center" valign="middle">
						<a href="javascript:;" onclick="showPerformance(<?php echo $p_rows[0]; ?>);">
							<?php echo $p_rows[1]; ?>
						</a>
						</td>
		<?php
					}else{
		?>
		  </tr><tr>
			<td width="50" height="25" align="center" valign="middle"><a href="#" onclick="javascript:openWin=open('show_performance.php?action=m&p_id=<?php echo $p_rows[0]; ?>' ,'','width=450,height=450,scrollbars=no');"><?php echo $p_rows[1]; ?></a></td>
		<?php
						$num = 0;
					}
					$num++;
				}
		?>
			</tr>
		</table>
	</div>
</div>
<script>
	function showPerformance(id){
		url = "show_performance.php?action=m&p_id="+id;
		//iframe窗
		layer.open({
			type: 2,
			title: false,
			shade: [0],
			area: ['450PX', '400px'],
			anim: 2,
			content: url //iframe的url，no代表不显示滚动条
		});
	}
</script>
</body>
</html>