-- MySQL dump 10.13  Distrib 5.5.53, for Win32 (AMD64)
--
-- Host: localhost    Database: db_office
-- ------------------------------------------------------
-- Server version	5.5.53

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `db_office`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `db_office` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db_office`;

--
-- Table structure for table `tb_company`
--

DROP TABLE IF EXISTS `tb_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_company` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `f_name` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '标题',
  `f_content` text CHARACTER SET utf8 NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=gb2312 COMMENT='企业信息列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_company`
--

LOCK TABLES `tb_company` WRITE;
/*!40000 ALTER TABLE `tb_company` DISABLE KEYS */;
INSERT INTO `tb_company` VALUES (1,'公司简介','本公司是一家软件程序开发为核心的高科技企业，历年来，开发了办公自动化管理系统、电子商务、个人博客等网站，都得到了广大客户的好评。'),(2,'图书借阅制度','	图书借阅规定\r\n为了加强公司内部图书的管理和有效地利用，也为方便大家能够及时找到所须图书，现规定如下：\r\n（1）所借图书必须到图书管理员处登记。\r\n（2）员工所借图书不能超过12本，特殊情况除外（例如制作目录等）。\r\n（3）在公司工作不超过3个月的新员工所借图书不能超过3本。\r\n（4）所借图书应及时归还，归还期限为1～3个月，如果3个月内不归还，请及时通知图书管理员，并说明原因。\r\n（5）本人所借图书，如果借给别人，应及时收回，或者归还让他人再借；否则，丢失由借阅人等价赔偿。\r\n（6）所借图书不能带回家，特殊情况应向图书管理员说明，以做详细记录。\r\n（7）如果所借图书丢失，由借阅人等价赔偿。\r\n（7）离职员工，离职前应将所有图书归还并签字，否则须等价赔偿。\r\n（8）阅读时注意保护图书的完好。\r\n（9）以上规定公司又最终解释权。'),(3,'员工行为规范','1、员工应按时上下班，不准迟到（早退），否则扣资。\r\n2、员工因故不能正常上班者，须向经理请假，无故旷工3日以上（含3日）视为自动离职。\r\n3、工作期间外出需向部门经理请假，回来后需向部门经理销假，外出时间过长，将扣除当天工资的相应部分。\r\n4、上班时间不得谈与公司业务无关的话题、做与公司业务无关的事（如看报、看小说）、未经允许上网、在公司计算机上玩电脑游戏、看VCD、利用公司设备干个人私事、与工作无关的个人电话不得超过5分钟（包括接听电话）。\r\n5、不准带闲杂人等到公司聊天或从事与工作无关的事情。\r\n6、上班时间不许使用QQ、飞鸽传书等即时通讯软件谈与工作无关的事情。\r\n7、在公司应团结互助，不允许同事之间发生争吵、打仗等情况，如发生争吵、打仗，轻者扣除奖金，重者开除出公司。\r\n8、工作期间要保持良好的精神状态，积极高效地完成任务，不能带情绪工作，工作或其他方面出现问题要相互忍让，解决不了的问题要向经理汇报。\r\n9、休息时间听音乐，看电视等声音不要过大，不要影响他人工作或休息。\r\n10、未经经理允许员工不得私自拆卸微机，如私自拆卸计算机，罚款500元～5000元。\r\n11、不得拷贝整本正在写作的或正在制作的图书或光盘（包括前后累加章节）回家，参考图书不得未经整理整本或整张拷贝。\r\n12、员工所编写的程序，未经总经理允许不得私自拷贝，如发现拷贝，罚款200～500元。\r\n13、要爱护公司设施，不得乱贴、乱画、带走、损坏（电脑、桌椅、屏风、地板等），要保持室内环境卫生，不得乱丢垃圾，不得在公司办公区内吸烟。\r\n14、正常开关计算机，休息时注意关闭计算机或显示器电源，如发现机器异常速向经理反应。\r\n15、正式员工如须离开本公司，须提前1个月向总经理申请。\r\n16、试用人员如有意隐瞒本人真实情况和假报虚报个人资料、品行不良或工作成绩欠佳及无故旷工者，公司可随时停止试用，予以解雇，试用不满3日者，按劳动法规定不发放工资。\r\n17、试用员工如须离开本公司，须提前3天书面告之部门负责人，并由部门负责人提交给总经理。\r\n18、除办理公司业务外，不得对外擅用本公司名义办理其他业务。\r\n19、不得泄露本公司机密，不得随意翻阅不属自己负责的文件、账簿、表册或函件。\r\n20、对所保管的文书财物及一切公物不得私自携出或出借。\r\n	'),(4,'保险管理制度','                    第一章 总则\r\n\r\n第一条：为实施公司保险管理制度，构造合理的员工保险体系，特制定本办法。 \r\n\r\n                  第二章 保险种类\r\n\r\n第二条：公司投保的保险种类有：社会养老保险、失业保险、基本医疗保险、生育保险、工伤保险、意外伤害保险。\r\n\r\n第三条  社会养老保险。（自愿）\r\n\r\n1、公司各类职工按国家规定，均应办理强制性养老保险社会统筹。\r\n\r\n2、实行企业缴费与个人缴费相结合，企业缴费比例为全部职工当月工资总额的21%，个人缴纳8%，如有变动按当地政府文件规定。\r\n\r\n3、养老金的计发根据当地政府社会保险部门文件规定。\r\n\r\n第四条  失业保险。（自愿）\r\n\r\n1、公司按政府有关规定，向当地社会保险管理局办理有关手续。\r\n\r\n2、实行企业缴费与个人缴费相结合，公司按全部职工当月工资总额的百分比（2%）缴纳失业保险费，个人缴纳1%。\r\n\r\n第五条  医疗保险。\r\n\r\n公司根据国家相关政策，医疗保险由长春市医疗保险管理局进行统一管理。\r\n\r\n1．当地有医疗保险社会统筹时，公司应按规定参加，为全体职工办理相应的手续（试用期过后即给办理）。\r\n\r\n2．医疗保险包括：基本医疗保险、生育保险、工伤保险。\r\n\r\n（1）基本医疗保险实行企业缴费与个人缴费相结合，公司缴纳全部职工当月工资总额的7%，个人缴纳2%。\r\n\r\n（2）生育保险由公司缴纳，个人不缴纳。比例为公司全部职工当月工资总额的0.7%。\r\n\r\n（3）工伤保险由公司缴纳，个人不缴纳。比例为公司全部职工当月工资总额的1%。\r\n\r\n第六条  意外伤害保险\r\n\r\n公司为经常出差及特殊工种人员向当地商业保险机构办理有关意外伤害保险手续。如员工在长春市或吉林省外发生意外伤害事故，均统一由保险公司进行赔偿。\r\n\r\n第七条  住房公积金（详见《住房公积金管理条例。》）\r\n\r\n    公司为经理级以上的员工缴纳住房公积金，比例为：公司缴纳人员工资总额的10%（其中公司5%，个人5%）,有变化按国家条例执行。\r\n\r\n第八条  商业保险的选择\r\n\r\n随着社会保险的发展和提供的商业性保险品种的增多，公司应精心选择合适的保险机构和保险品种，以求获得低成本、高效益的保险效果。\r\n\r\n \r\n\r\n第三章 保险的领取\r\n第八条  失业保险领取标准\r\n\r\n1、失业前在企业连续工作1年以上不足5年，领取最长期限为12个月；\r\n\r\n2、失业前在企业连续工作5年以上，领取最长期限为24个月。\r\n\r\n第九条  失业保险领取或失去资格的情形。\r\n\r\n1、领取资格情形：\r\n\r\n（1）    公司依法破产后\r\n\r\n（2）    职工在公司整顿期被精简\r\n\r\n（3）    公司被撤消解散后；\r\n\r\n（4）    职工终止或解除了劳动合同\r\n\r\n（5）    被辞退、除名或开除\r\n\r\n2、失去资格情形：\r\n\r\n（1）    领取期限届满；\r\n\r\n（2）    参军或出国定居\r\n\r\n（3）    重新就业\r\n\r\n（4）    无正当理由，两次拒绝接受就业机构介绍的工作。\r\n\r\n（5）    在领取期间被劳教或被判刑。\r\n\r\n第十条  生育保险待遇。\r\n\r\n根据国家有关规定，公司对女职工实行特殊劳动保护。\r\n\r\n1、禁止女职工从事不利于身体健康的工作。\r\n\r\n2、划定女职工经期、已婚待孕期、怀孕期、哺乳期禁忌从事的劳动范围，并严格遵守。\r\n\r\n3、女职工在怀孕期、产期、哺乳期，享有基本工资，不得解除劳动合同，允许在劳动时间内进行产前检查。\r\n\r\n4、女职工产假为90天。产前产后可自定。\r\n\r\n5、生育津贴的领取按长春市生育保险有关规定执行。\r\n\r\n第十一条  养老保险的领取\r\n\r\n根据社会保险局规定，必需连续参保十五年，达到退休年龄方可领取。养老保险于退休后统一由社会保险管理局划入到银行进行支付。\r\n\r\n男60岁，女55岁之后享受养老保险待遇。\r\n\r\n第十二条  公司为每位员工建立保险档案。\r\n\r\n第十三条  保险范围一般在中国境内。\r\n\r\n \r\n\r\n第四章  保险支付或索赔\r\n第十四条 保险期内住院医疗\r\n\r\n员工如在保险期内必须进行住院治疗的，可直接携带长春市医保卡，医疗保健本及个人身份证到医院住院处办理入院手续，出院时直接进行费用结算，无需再到长春市医保局和公司人力资源部。\r\n\r\n第十五条 个人账户的应用\r\n\r\n    员工在职期间医保卡个人账户的费用专款专用，用途有：药店购药、门诊挂号、门诊检查费用（B超、X线、化验等），个人账户费用用完后用现金补充。\r\n\r\n第十六条 工伤保险\r\n\r\n如发生工伤，公司人力资源部及时向长春市医保局报案，并跟据医保局的规定收集整理报销凭据。工伤认定程序参见《长春市工伤管理条例》。\r\n\r\n第十七条 生育保险\r\n\r\n女员工怀孕后，到长春市医保局办理生育登记，女员工生产后6个月到长春市医保局办理生育津贴领取。\r\n\r\n第十八条 意外伤害保险\r\n\r\n如发生投保条款中规定的事件，应由公司人力资源部或员工向商业保险公司申请支付或索赔。发票维持现场原貌或保存证据，在索赔时应提供所需要的各类证明。\r\n\r\n \r\n\r\n第五章 附则\r\n \r\n\r\n第十九条 公司人力资源部应及时办理与职工新聘用、调岗和辞退相关的保险关系的初建、增减、企业间转移、撤保、续约等事务。\r\n\r\n第二十条 员工参保时间\r\n\r\n1、社会养老保险及失业保险：试用期后（可自愿）\r\n\r\n2、医疗保险：试用期后（必须）\r\n\r\n3、住房公积金：到公司两年以上的员工（自愿）\r\n\r\n第二十一条  鉴于目前正进入社会保险峰的重大时期，保险法规、政策变动较大，公司就密切关注中央及政府保险法规、政策动态并及时作出相应调整。\r\n\r\n第二十二条  本制度与当地政策抵触时，以当地政府规定为准。\r\n\r\n第二十三条  本制度由人力资源部制定，并由总经理批准实施。\r\n\r\n第二十四条  本制度最终解释权为吉林省明日科技有限公司综合人力资源部。\r\n\r\n福利管理规定\r\n一、公司为工作一年以上的员工提供带薪特别休假\r\n\r\n1、在公司连续工作1年以上未满3年者每年可给予带薪特别休假3天（含法定假日，下同），工作3年以上每增加1年给予带薪特别休假增加1天，但至多以30天为限。\r\n\r\n2、员工在休假之前1年，病、事等假累计达15天或旷工达3天以上者不给予带薪特别假。\r\n\r\n3、在休假之前1年，病、事等假累计达6天以上不足15天者，其超过天数的冲减一半特别假相应天数。\r\n\r\n4、带薪特别休假期间享受基本工资待遇。\r\n\r\n二、公司统一安排的旅游\r\n\r\n   公司每年安排两次旅游，一次省外，一次省内。\r\n\r\n  有下列情形之一者不享受此福利：\r\n\r\n1、实习人员\r\n\r\n2、未过试用期的普通职员\r\n\r\n3、年纪超过45岁(身体因素)\r\n\r\n4、后勤人员\r\n\r\n5、员工家属\r\n\r\n三、公司为每位员工供提供免费午餐、提供各式饮品、雪糕等。\r\n\r\n四、公司定期为员工提供康乐活动，丰富员工的业余生活。\r\n\r\n五、公司为加班员工提供晚餐补助。');
/*!40000 ALTER TABLE `tb_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_controller`
--

DROP TABLE IF EXISTS `tb_controller`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_controller` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `manager` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '管理员账号',
  `mana_pwd` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '管理员密码',
  `purview` int(4) NOT NULL COMMENT '级别权限',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gb2312 COMMENT='管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_controller`
--

LOCK TABLES `tb_controller` WRITE;
/*!40000 ALTER TABLE `tb_controller` DISABLE KEYS */;
INSERT INTO `tb_controller` VALUES (1,'mr','mrsoft',9);
/*!40000 ALTER TABLE `tb_controller` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_depart`
--

DROP TABLE IF EXISTS `tb_depart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_depart` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `d_name` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '部门名称',
  `up_depart` int(4) NOT NULL DEFAULT '0' COMMENT '上层部门',
  `remark` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '部门备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=gb2312 COMMENT='部门管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_depart`
--

LOCK TABLES `tb_depart` WRITE;
/*!40000 ALTER TABLE `tb_depart` DISABLE KEYS */;
INSERT INTO `tb_depart` VALUES (32,'C++',30,'C++'),(33,'质量部',30,'图书质量,产品质量，其他'),(34,'人事部',0,'无'),(31,'VC',30,'VC'),(29,'总经理',0,'总经理'),(30,'部门经理',0,'部门经理'),(45,'ceshi',32,'fasdf ');
/*!40000 ALTER TABLE `tb_depart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_group`
--

DROP TABLE IF EXISTS `tb_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_group` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `u_group` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '用户组',
  `u_member` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '人员',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=gb2312 COMMENT='用户组管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_group`
--

LOCK TABLES `tb_group` WRITE;
/*!40000 ALTER TABLE `tb_group` DISABLE KEYS */;
INSERT INTO `tb_group` VALUES (23,'试用员工','小新小刘,'),(22,'正式员工','小丽,小王,小田,小军,'),(17,'部门经理','小张,'),(24,'总经理','王总,');
/*!40000 ALTER TABLE `tb_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_iss`
--

DROP TABLE IF EXISTS `tb_iss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_iss` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `i_title` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '标题',
  `i_content` varchar(200) CHARACTER SET utf8 NOT NULL COMMENT '内容',
  `i_time` date NOT NULL COMMENT '日期',
  `i_state` int(1) NOT NULL DEFAULT '3' COMMENT '是否审核(0,1,2)',
  `p_id` int(4) NOT NULL COMMENT '申请人id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=gb2312 COMMENT='审核列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_iss`
--

LOCK TABLES `tb_iss` WRITE;
/*!40000 ALTER TABLE `tb_iss` DISABLE KEYS */;
INSERT INTO `tb_iss` VALUES (14,'测试4','测试一下','2017-12-26',0,26),(10,'审请出差','由于工作原因，需要出差2天','2007-12-04',3,1),(11,'培训','我想参加Word基础知识的培训，希望经理给予批示。','2007-12-04',3,1),(12,'培训审请','232312321','2007-12-04',3,21),(17,'申请购买笔记本一台','笔记本老旧，申请购买新笔记本一台','2018-04-18',3,26),(16,'申请买书','申请买书申请买书','2018-04-18',1,28);
/*!40000 ALTER TABLE `tb_iss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_list`
--

DROP TABLE IF EXISTS `tb_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_list` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `f_name` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '功能名称',
  `f_type` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '所属类别',
  `o_url` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '链接地址',
  `o_group` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '0' COMMENT '开放工作组',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=gb2312 COMMENT='功能表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_list`
--

LOCK TABLES `tb_list` WRITE;
/*!40000 ALTER TABLE `tb_list` DISABLE KEYS */;
INSERT INTO `tb_list` VALUES (1,'公司简介','企业信息','qyxx/company_info.php','总经理,试用员工,正式员工,部门经理,'),(2,'规章制度','企业信息','qyxx/r_system.php','总经理,试用员工,正式员工,部门经理,'),(4,'企业管理','企业信息','qyxx/c_manage.php','总经理,部门经理,正式员工,'),(5,'任务绩效','企业绩效','qyjx/t_performance.php','总经理,试用员工,正式员工,部门经理,'),(6,'质量绩效','企业绩效','qyjx/m_performance.php','总经理,试用员工,正式员工,部门经理,'),(7,'优秀员工','企业绩效','qyjx/exc_staf.php','总经理,部门经理,'),(9,'企业公告','人事消息','rsxx/p_message.php','总经理,试用员工,正式员工,部门经理,'),(10,'活动安排','人事消息','rsxx/p_message.php','总经理,试用员工,正式员工,部门经理,'),(11,'消息管理','人事消息','rsxx/p_manage.php','总经理,试用员工,正式员工,部门经理,'),(12,'发布审核','审核批示','shps/au_issuance.php','总经理,试用员工,正式员工,部门经理,'),(13,'批示审核','审核批示','shps/au_read.php','部门经理,总经理,'),(14,'上下班登记','考勤管理','kqgl/work_note.php','总经理,试用员工,正式员工,部门经理,'),(15,'病事假登记','考勤管理','kqgl/work_note.php','总经理,试用员工,正式员工,部门经理,'),(16,'加班登记','考勤管理','kqgl/work_note.php','总经理,试用员工,正式员工,部门经理,'),(17,'考勤记录','考勤管理','kqgl/manage_note.php','总经理,正式员工,'),(18,'工作反馈','个人计划','grjh/person_plan.php','总经理,试用员工,正式员工,部门经理,'),(19,'周 计 划','个人计划','grjh/person_plan.php','总经理,试用员工,正式员工,部门经理,'),(20,'月 计 划','个人计划','grjh/person_plan.php','总经理,试用员工,正式员工,部门经理,'),(21,'年 计 划','个人计划','grjh/person_plan.php','总经理,试用员工,正式员工,部门经理,'),(22,'任务计划','个人计划','grjh/person_plan.php','总经理,试用员工,正式员工,部门经理,'),(23,'职员浏览','职员天地','zytd/personnel_air.php','总经理,试用员工,正式员工,部门经理,'),(24,'意 见 箱','职员天地','zytd/lyb.php','试用员工,正式员工,部门经理,总经理,'),(25,'个人设定','职员天地','zytd/personnel_air.php','总经理,试用员工,正式员工,部门经理,'),(26,'绩效评定','企业绩效','qyjx/ass_read.php','部门经理,总经理,');
/*!40000 ALTER TABLE `tb_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_lyb`
--

DROP TABLE IF EXISTS `tb_lyb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_lyb` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `l_title` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '主题',
  `l_content` varchar(200) CHARACTER SET utf8 NOT NULL COMMENT '内容',
  `l_time` date NOT NULL COMMENT '留言时间',
  `is_reply` int(1) NOT NULL COMMENT '是否回复',
  `r_back` varchar(200) CHARACTER SET utf8 NOT NULL COMMENT '回复内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=gb2312 COMMENT='意见箱表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_lyb`
--

LOCK TABLES `tb_lyb` WRITE;
/*!40000 ALTER TABLE `tb_lyb` DISABLE KEYS */;
INSERT INTO `tb_lyb` VALUES (9,'建议开通企业微博','建议开通企业微博，更好宣传公司','2017-12-21',1,'建议很好，已经提议给经理'),(10,'给公司提意见','1.做好宣传\r\n2.弹性上班\r\n3.。。','2018-04-21',0,'');
/*!40000 ALTER TABLE `tb_lyb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_person`
--

DROP TABLE IF EXISTS `tb_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_person` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `p_title` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '标题',
  `p_content` mediumtext CHARACTER SET utf8 NOT NULL COMMENT '内容',
  `p_time` date NOT NULL COMMENT '发布时间',
  `u_id` int(4) NOT NULL COMMENT '用户ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=gb2312 COMMENT='人事表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_person`
--

LOCK TABLES `tb_person` WRITE;
/*!40000 ALTER TABLE `tb_person` DISABLE KEYS */;
INSERT INTO `tb_person` VALUES (12,'串休','由于公司这周日停电，所以将周一与周日串休，周日正常上班，周一休息，请注意上班时间，谢谢配合','2018-04-21',9),(11,'羽毛球单打决赛','今天下午4点，在体育馆举行本次羽毛球单打决赛。\r\n参赛人员：全体员工\r\n                                     2007年12月4日','2007-12-04',10),(13,'元旦放假通知','元旦放假3天，请各部门提前做好放假准备工作。','2017-12-21',9),(15,'元旦放假通知','元旦放假3天，请各部门提前做好放假准备！','2017-12-22',9);
/*!40000 ALTER TABLE `tb_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_plan`
--

DROP TABLE IF EXISTS `tb_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_plan` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `p_plan` varchar(200) CHARACTER SET utf8 NOT NULL COMMENT '计划内容',
  `p_type` int(4) NOT NULL COMMENT '类别',
  `p_id` int(4) NOT NULL COMMENT '所属人id',
  `p_time` date NOT NULL COMMENT '日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=gb2312 COMMENT='计划列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_plan`
--

LOCK TABLES `tb_plan` WRITE;
/*!40000 ALTER TABLE `tb_plan` DISABLE KEYS */;
INSERT INTO `tb_plan` VALUES (35,'本月主要完成了办公自动化、个人博客等程序',20,27,'2007-12-05'),(34,'本月主要完成了办公自动化、个人博客等程序',20,27,'2007-12-05'),(33,'本周主要修改办公自动化程序',19,27,'2007-12-05'),(32,'测试办公自动化',18,27,'2007-12-05'),(31,'开发图书管理系统',19,18,'2007-12-05'),(30,'工作计划工作计划\r\n工作计划',18,21,'2007-12-04'),(20,'办公自动化管理系统项目开发',18,21,'2007-12-04'),(21,'完成办公自动化管理系统的开发',19,21,'2007-12-04'),(22,'本月主要测试程序\r\n整理光盘',20,21,'2007-12-04'),(23,'测试，整理光盘',21,21,'2007-12-04'),(24,'测试',22,21,'2007-12-04'),(37,'继续工作',22,27,'2007-12-05'),(36,'测试、整理光盘',21,26,'2007-12-05'),(38,'覆盖广泛覆盖',19,28,'2010-08-12'),(39,'完成二期测试',18,26,'2017-12-26'),(40,'完成编码',18,26,'2017-12-26'),(41,'测试一下',18,26,'2017-12-26'),(42,'测试3',18,26,'2017-12-27'),(43,'是大发发',19,26,'2017-12-19'),(44,'周计划2',19,26,'2017-12-19'),(45,'这是月计算',20,26,'2017-12-26'),(46,'这是本月计划',20,28,'2018-04-17'),(47,'这是本月计划',20,28,'2018-04-17'),(48,'录制视频',22,28,'2018-04-20'),(49,'录制视频',18,26,'2018-04-21');
/*!40000 ALTER TABLE `tb_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_register`
--

DROP TABLE IF EXISTS `tb_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_register` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `r_date` date NOT NULL COMMENT '登记日期（年月日）',
  `r_time` time NOT NULL COMMENT '登记时间（时分秒）',
  `r_type` int(1) NOT NULL COMMENT '登记类型（上、下班等）',
  `r_state` int(1) NOT NULL DEFAULT '3' COMMENT '登记状态（迟到、早退）',
  `r_remark` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '登记备注（原因）',
  `r_id` int(4) NOT NULL COMMENT '功能类别（上下班、病事假）',
  `p_id` int(4) NOT NULL COMMENT '员工编号（员工id）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=gb2312 COMMENT='登记表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_register`
--

LOCK TABLES `tb_register` WRITE;
/*!40000 ALTER TABLE `tb_register` DISABLE KEYS */;
INSERT INTO `tb_register` VALUES (65,'2018-04-25','14:27:56',1,1,'',14,26),(66,'2018-04-25','14:28:51',0,0,'',14,26),(67,'2018-04-25','14:31:33',1,1,'',14,26),(60,'0000-00-00','00:00:00',4,3,'',15,26),(61,'2018-04-25','14:07:12',2,0,'',16,26),(62,'2018-04-25','14:08:44',2,0,'',16,26),(63,'2018-04-25','14:11:21',4,3,'',15,26),(64,'2018-04-25','14:11:36',3,0,'',16,26),(68,'2018-04-25','14:35:49',1,1,'测试',14,26);
/*!40000 ALTER TABLE `tb_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_setup`
--

DROP TABLE IF EXISTS `tb_setup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_setup` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `l_name` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '名称',
  `l_time` time NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=gb2312 COMMENT='上下班时间设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_setup`
--

LOCK TABLES `tb_setup` WRITE;
/*!40000 ALTER TABLE `tb_setup` DISABLE KEYS */;
INSERT INTO `tb_setup` VALUES (1,'上班签到','08:00:00'),(2,'下班签退','17:10:00'),(3,'加班签到','17:30:00'),(4,'加班签退','20:00:00');
/*!40000 ALTER TABLE `tb_setup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_superson`
--

DROP TABLE IF EXISTS `tb_superson`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_superson` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `s_fmonth` date NOT NULL COMMENT '第一个月份',
  `s_lmonth` date NOT NULL COMMENT '最后一个月份',
  `s_id` varchar(200) CHARACTER SET utf8 NOT NULL COMMENT '优秀员工id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=gb2312 COMMENT='优秀员工表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_superson`
--

LOCK TABLES `tb_superson` WRITE;
/*!40000 ALTER TABLE `tb_superson` DISABLE KEYS */;
INSERT INTO `tb_superson` VALUES (12,'2007-10-01','2007-12-31','小军,小娜,'),(16,'2018-03-01','2018-04-01','小张,'),(15,'2017-12-01','2017-12-31','小军,');
/*!40000 ALTER TABLE `tb_superson` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_users`
--

DROP TABLE IF EXISTS `tb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_users` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `u_user` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '账号',
  `u_pwd` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '密码',
  `u_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '员工姓名',
  `u_sex` char(1) CHARACTER SET utf8 DEFAULT NULL COMMENT '性别',
  `u_birth` date DEFAULT NULL COMMENT '出生日期',
  `u_address` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '地址',
  `u_tel` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '电话',
  `u_email` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '邮箱',
  `u_depart` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '用户组',
  `is_on` int(1) NOT NULL COMMENT '账户状态（1 ：正常，0：禁用）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=gb2312 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_users`
--

LOCK TABLES `tb_users` WRITE;
/*!40000 ALTER TABLE `tb_users` DISABLE KEYS */;
INSERT INTO `tb_users` VALUES (26,'1003','1003','小军','男','1985-02-25','','136542***','qq.com','32',1),(29,'1005','1005','小刘','男','0000-00-00','长春市南关区','5001','xiaoliu@qq.com','33',1),(25,'1002','1002','小丽','女','1985-02-25','','136542***','','34',1),(24,'1001','1001','王总','男','1985-02-25','','136542***','','32',1),(28,'1004','1004','小张','女','2010-08-12','555','555','','30',1);
/*!40000 ALTER TABLE `tb_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-26 15:52:13
