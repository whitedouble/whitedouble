<?php
date_default_timezone_set('Asia/Shanghai'); // 设置时区
if(!isset($_SESSION)) {
	session_start();
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>办公自动化系统</title>
	<link href="/css/style.css" rel="stylesheet" />
    <script src="/js/admin_js.js"></script>
    <script src="/js/jquery-2.1.1.min.js"></script>
	<script>
		// 展开菜单
		$(document).ready(function(){
			var path = window.location.pathname;    // 获取当前路径
			var link = $('.sub-menu a');            // 获取所有子菜单对象
			link.each(function () {                 // 遍历对象
				if($(this).attr('href').indexOf(path) != -1){   // 找到当前路径
					$(this).parent().parent().show();    // 展开菜单栏
				}
			});
		});
		function change(nu,lx){
			if(nu.style.display == "none"){
				nu.style.display = "";
			}else{
				nu.style.display = "none";
			}
		}
	</script>
</head>
<body>
<div class="top" style="background:url(/images/admin_bg.jpg) no-repeat ;" >
	<div class="head">
		<a href="/admin/logout.php">
			<span class="head-title">退出</span>
		</a>
	</div>
	<div class="clear"></div>
	<div class="group">
		<span class="group-title">用户名：管理员</span>
		<span class="group-title"><?php echo date('Y-m-d H:i:s') ?></span>
	</div>
</div>