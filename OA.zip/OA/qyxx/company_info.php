<?php
	session_start();
	include "../inc/chec.php";
	include "../conn/conn.php";
	$sqlstr = "select * from tb_company where id = 1";
	$result = mysqli_query($conn,$sqlstr);
	$info   = mysqli_fetch_row($result);
?>
<?php include('../top.php') ?>
<div class="container">
	<?php include('../left.php') ?>
	<div class="right">
	<table width="768" border="1" cellpadding="0" cellspacing="0" class="big_td">
		<tr>
			<td height="36" background="../images/list.jpg" id="list">公司简介</td>
		</tr>
		<tr>
			<td height="25" align="center" valign="top">
				<textarea cols="90" rows="25" readonly="readonly"><?php echo $info[2]; ?></textarea></td>
		</tr>
	</table>
	</div>
</div>
</body>
</html>
