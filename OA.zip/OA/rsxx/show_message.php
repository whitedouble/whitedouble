<?php
	include "../conn/conn.php";
	$sqlstr = "select * from tb_person where id=".$_GET['id'];
	$result = mysqli_query($conn,$sqlstr);
	$rows = mysqli_fetch_row($result);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body style="background-color:whitesmoke">
    <!--标题-->
    <h2 style="text-align: center">
        <?php echo $rows[1]; ?>
    </h2>
    <!--内容-->
    <div style="text-align: left;margin-top: 20px">
        <p><?php echo $rows[2]; ?></p>
    </div>
</body>
</html>
